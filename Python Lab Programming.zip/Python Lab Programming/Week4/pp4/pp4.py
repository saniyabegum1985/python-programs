with open("word.txt","w") as file: 
 file.write("I ") 
 file.write("a") 
