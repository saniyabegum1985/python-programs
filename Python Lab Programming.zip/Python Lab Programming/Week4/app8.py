txt=input("Enter a sentence:") 
print(txt.title())
